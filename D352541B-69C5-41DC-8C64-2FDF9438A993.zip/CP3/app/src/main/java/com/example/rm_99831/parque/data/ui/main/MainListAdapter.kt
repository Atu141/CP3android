package com.example.rm_99831.parque.data.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.rm_99831.R
import com.example.rm_99831.databinding.ParqueItemBinding
import com.example.rm_99831.parque.data.Parque
import com.squareup.picasso.Picasso

class MainListAdapter(
    private val onClick: (Parque) -> Unit
) : RecyclerView.Adapter<MainListAdapter.ParqueViewHolder>(){
    private var lista = listOf<Parque>()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MainListAdapter.ParqueViewHolder {
        val binding =
            ParqueItemBinding.inflate(LayoutInflater.from(parent.context),
                parent, false)
        return ParqueViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MainListAdapter.ParqueViewHolder, position: Int) {
        holder.bind(lista[position])
    }

    override fun getItemCount() = lista.size

    fun submitList(novaLista: List<Parque>) {
        lista = novaLista
        notifyDataSetChanged()
    }

    inner class ParqueViewHolder(private val binding: ParqueItemBinding)
        : RecyclerView.ViewHolder(binding.root) {
           fun bind(parque: Parque){
               binding.tvTitulo.text = parque.nome
               binding.tvLocalizacao.text = parque.localizacao
               binding.tvDescricao.text = parque.descricao
               Picasso.get()
                   .load(parque.urlImagem)
                   .error(R.drawable.erro)
                   .placeholder(R.drawable.loading)
                   .into(binding.ivParque)
               binding.root.setOnClickListener{
                   onClick(parque)
               }
           }
        }



}