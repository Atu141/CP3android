package com.example.rm_99831.parque.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ParqueRepository(private val context: Context){
    fun carregarParque(): List<Parque>{
        val json =
            context.assets.open("parques_diversao.json").bufferedReader().use { it.readText()
            }
        val tipo = object : TypeToken<List<Parque>>() {}.type
        return Gson().fromJson(json, tipo)

    }
}