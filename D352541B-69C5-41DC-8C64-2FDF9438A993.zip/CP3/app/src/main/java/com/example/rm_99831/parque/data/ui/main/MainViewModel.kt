package com.example.rm_99831.parque.data.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.rm_99831.parque.data.Parque
import com.example.rm_99831.parque.data.ParqueRepository

class MainViewModel(application: Application): AndroidViewModel(application) {
    private val repo = ParqueRepository(application)

    private val _lista = MutableLiveData<List<Parque>>()
    val lista : LiveData<List<Parque>> get() = _lista

    init {
        _lista.value = repo.carregarParque()
    }
}