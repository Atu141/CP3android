package com.example.rm_99831.parque.data.ui.detalhe

import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.rm_99831.R
import com.example.rm_99831.databinding.ActivityDetalheBinding
import com.example.rm_99831.parque.data.Parque
import com.squareup.picasso.Picasso

class DetalheActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetalheBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalheBinding .inflate(layoutInflater)
        setContentView( binding.root)
        configuraParque(getParqueDaOutraTela())
    }

    private fun getParqueDaOutraTela(): Parque? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES .TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PARQUE ,
                Parque::class.java)
        } else {
            @Suppress("DEPRECATION" )
            intent.getParcelableExtra(EXTRA_PARQUE)
        }
    }

    private fun configuraParque (parque: Parque?) {
        parque?. let {
            with(binding) {
                tvTitulo.text = it.nome
                tvDescricao .text = it.descricao
                tvlocalizacao.text = it.localizacao
                Picasso.get().load( it.urlImagem)
                    .error( R.drawable.erro)
                    .placeholder( R.drawable.loading)
                    .into( ivParque )
            }
        }
    }

    companion object {
        const val EXTRA_PARQUE = "EXTRA_PARQUE"
    }
}