package com.example.rm_99831.parque.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Parque (
    val nome: String,
    val localizacao: String,
    val descricao: String,
    val urlImagem: String

) : Parcelable{

}
